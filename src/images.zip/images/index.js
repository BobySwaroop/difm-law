import DIFMLAWCorporatelawyers from "./DIFMLAWCorporatelawyers.svg";
import DIFMLAWEmployeementlawyers from "./DIFMLAWEmployeementlawyers.svg";
import DIFMLAWRealestatelawyers from "./DIFMLAWRealestatelawyers.svg";
import DIFMLAWImmigirationlawyers from "./DIFMLAWImmigirationlaw.svg";
import DIFMLAWPropertylawyers from "./DIFMLAWPropertyLawyer.svg";
import DIFMLAWinjurylawyer from "./DIFMLAWinjurylawyer.svg";
import DIFMLAWDefencelawyers from "./DIFMLAWDefencelawyers.svg";
import DIFMLAWFamilylawyers from "./DIFMLAWFamilylawlawyers.svg";



export {
    DIFMLAWCorporatelawyers,
     DIFMLAWEmployeementlawyers,
      DIFMLAWRealestatelawyers,
       DIFMLAWImmigirationlawyers,
        DIFMLAWPropertylawyers,
         DIFMLAWinjurylawyer, 
         DIFMLAWDefencelawyers,
         DIFMLAWFamilylawyers
}